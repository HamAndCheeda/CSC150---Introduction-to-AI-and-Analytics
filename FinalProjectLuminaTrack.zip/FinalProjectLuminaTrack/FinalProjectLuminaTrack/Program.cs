﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace LuminaTrack
{
    // The Entry Point Class
    class Program
    {
        // This is the "Main" method the compiler was looking for
        static void Main(string[] args)
        {
            Console.Title = "LuminaTrack Engine";

            // Initialize the system
            var manager = new ContextManager();

            Console.WriteLine("--- Welcome to LuminaTrack ---");
            Console.WriteLine("Initializing focus environments...");

            // Execute a context switch
            manager.SwitchContext("Deep Work");

            if (manager.ActiveContext != null)
            {
                Console.WriteLine($"\nCurrent Active Context: {manager.ActiveContext.Name}");
                Console.WriteLine($"Focus Timer set for: {manager.ActiveContext.FocusTimerMinutes} minutes");
                Console.WriteLine("Resources Loaded:");

                foreach (var resource in manager.ActiveContext.Resources)
                {
                    Console.WriteLine($"- {resource}");
                }
            }

            Console.WriteLine("\nPress any key to exit.");
            Console.ReadKey();
        }
    }

    // --- Logic Classes (The code from before) ---

    public class WorkContext
    {
        public string Name { get; set; }
        public List<string> Resources { get; set; } = new List<string>();
        public int FocusTimerMinutes { get; set; }

        public WorkContext(string name, int timer)
        {
            Name = name;
            FocusTimerMinutes = timer;
        }
    }

    public class ContextManager
    {
        private List<WorkContext> _availableContexts;
        public WorkContext ActiveContext { get; private set; }

        public ContextManager()
        {
            _availableContexts = new List<WorkContext>();
            InitializeDefaultContexts();
        }

        private void InitializeDefaultContexts()
        {
            var deepWork = new WorkContext("Deep Work", 90);
            deepWork.Resources.Add("Visual Studio Project");
            deepWork.Resources.Add("Technical Documentation");

            _availableContexts.Add(deepWork);
        }

        public void SwitchContext(string contextName)
        {
            var target = _availableContexts.FirstOrDefault(c => c.Name == contextName);
            if (target != null)
            {
                ActiveContext = target;
                Console.WriteLine($"[System] Successfully shifted to {target.Name}.");
            }
        }
    }
}